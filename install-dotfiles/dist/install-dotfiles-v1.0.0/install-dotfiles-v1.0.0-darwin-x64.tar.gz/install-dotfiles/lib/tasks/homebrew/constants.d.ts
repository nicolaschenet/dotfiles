export declare const BREW_FORMULAE: string[];
export declare const BREW_CASKS: string[];
