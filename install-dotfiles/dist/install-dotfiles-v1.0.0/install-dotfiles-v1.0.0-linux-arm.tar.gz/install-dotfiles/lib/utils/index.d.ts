export declare const execCommand: (cmd: string) => Promise<unknown>;
