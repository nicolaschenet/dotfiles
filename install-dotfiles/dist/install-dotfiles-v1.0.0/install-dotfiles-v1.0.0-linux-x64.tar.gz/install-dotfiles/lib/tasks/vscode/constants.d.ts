export declare const VSCODE_EXTENSIONS: string[];
