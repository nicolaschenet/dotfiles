import Listr from 'listr';
export declare const backupOldDotfiles: () => Listr<any>;
export declare const installDotFiles: () => Listr<any>;
