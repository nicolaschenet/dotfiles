export interface UserInfo {
    firstname?: string;
    lastname?: string;
    email?: string;
}
