import { Command } from '@oclif/command';
declare class InstallDotfiles extends Command {
    run(): Promise<void>;
}
export = InstallDotfiles;
