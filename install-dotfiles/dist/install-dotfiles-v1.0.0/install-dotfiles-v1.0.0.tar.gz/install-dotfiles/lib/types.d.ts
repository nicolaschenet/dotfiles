export interface UserInfo {
    gitUserName?: string;
    gitUserEmail?: string;
    password?: string;
}
