export declare const YARN_PACKAGES: string[];
