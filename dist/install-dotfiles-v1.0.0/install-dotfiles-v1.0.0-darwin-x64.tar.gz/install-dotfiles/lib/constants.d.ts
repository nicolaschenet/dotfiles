export declare const HOME: string;
