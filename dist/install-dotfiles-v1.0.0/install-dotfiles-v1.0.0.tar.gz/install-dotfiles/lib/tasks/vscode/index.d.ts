import Listr from 'listr';
export declare const installVsCodeExtensions: () => Listr<any>;
