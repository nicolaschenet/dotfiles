interface DotfilesMap {
    [key: string]: string;
}
export declare const DOTFILES: DotfilesMap;
export {};
